// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyBW4xSeR_tlB6AXX903_Yz0Kn8BjoZNtGY",
  authDomain: "authapp-d95a7.firebaseapp.com",
  projectId: "authapp-d95a7",
  storageBucket: "authapp-d95a7.appspot.com",
  messagingSenderId: "549145721034",
  appId: "1:549145721034:web:894ac9917b7ee47c709c33",
  measurementId: "G-BDS6G7TQQ4",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
