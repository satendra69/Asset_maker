import React from "react";
import ExampleWithLocalizationProvider from "./DataTable/Provider";

function AdminHeader() {
  return <div></div>;
}

export default AdminHeader;
