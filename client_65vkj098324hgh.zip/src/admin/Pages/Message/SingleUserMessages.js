import React from "react";

function SingleUserMessages() {
  return <div>SingleUserMessages</div>;
}

export default SingleUserMessages;
